﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Takehome_Week08_Yoel_Isaac_0706022310020
{
    public partial class Form1 : Form
    {
        DataTable muncul = new DataTable();
        int harga = 0;
        int pajak = 0;
        bool kurang;
        int index;
        bool ada; bool ada2; bool ada3;
        bool ada4; bool ada5; bool ada6;
        bool ada7; bool ada8; bool ada9;
        bool ada10; bool ada11; bool ada12;
        bool ada14; bool ada15; bool ada16;
        bool ada17; bool ada18; bool ada19;
        bool ada13;
        public Form1()
        {
            InitializeComponent();
            if (muncul.Rows.Count == 0)
            {
                tb_subtotal.Text = "0,00";
                tb_total.Text = "0,00";
            }
        }


        private void subtotal(int harga, double pajak, bool kurang)
        {

            int hitung = 0;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                harga = harga + Convert.ToInt32(muncul.Rows[i][3].ToString());
            }
            if (kurang == false)
            {
                hitung = hitung + harga;
                pajak = harga + (hitung * 0.1);
            }
            else if (kurang == true)
            {
                hitung = hitung - harga;
                harga = hitung;
                pajak = pajak - (harga + (hitung * 0.1));
                kurang = false;
            }


            tb_subtotal.Text = harga.ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
            tb_total.Text = pajak.ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            muncul.Columns.Add("Item Name");
            muncul.Columns.Add("Quantity");
            muncul.Columns.Add("Price");
            muncul.Columns.Add("Total");


            dgv_menu.DataSource = muncul;
        }
       
        private void btn_shirt1_Click(object sender, EventArgs e)
        {
            ada = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "T-Shirt Grey")
                {
                    ada = true;
                }
            }

            if (ada == false)
            {
                muncul.Rows.Add("T-Shirt Grey", "1", "50000", "50000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "T-Shirt Grey")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }
        private void btn_shirt2_Click(object sender, EventArgs e)
        {
            ada2 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "T-Shirt Beige")
                {
                    ada2 = true;
                }
            }

            if (ada2 == false)
            {
                muncul.Rows.Add("T-Shirt Beige", "1", "60000", "60000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada2 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "T-Shirt Beige")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shirt3_Click(object sender, EventArgs e)
        {
            ada3 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "T-Shirt Blue")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada3 = true;
                }
            }

            if (ada3 == false)
            {
                muncul.Rows.Add("T-Shirt Blue", "1", "70000", "70000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada3 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "T-Shirt Blue")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shoes1_Click(object sender, EventArgs e)
        {
            ada10 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Black Shoes")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada10 = true;
                }
            }

            if (ada10 == false)
            {
                muncul.Rows.Add("Black Shoes", "1", "550000", "550000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada10 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Black Shoes")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shoes2_Click(object sender, EventArgs e)
        {
            ada11 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Red Shoes")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada11 = true;
                }
            }

            if (ada11 == false)
            {
                muncul.Rows.Add("Red Shoes", "1", "660000", "660000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada11 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Red Shoes")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shoes3_Click(object sender, EventArgs e)
        {
            ada12 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Purple Shoes")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada12 = true;
                }
            }

            if (ada12 == false)
            {
                muncul.Rows.Add("Purple Shoes", "1", "770000", "770000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada12 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Purple Shoes")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_tshirt1_Click(object sender, EventArgs e)
        {
            ada14 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Navy Shirt")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada14 = true;
                }
            }

            if (ada14 == false)
            {
                muncul.Rows.Add("Navy Shirt", "1", "500000", "500000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada14 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Navy Shirt")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_tshirt2_Click(object sender, EventArgs e)
        {
            ada15 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Light Blue Shirt")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada15 = true;
                }
            }

            if (ada15 == false)
            {
                muncul.Rows.Add("Light Blue Shirt", "1", "600000", "600000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada15 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Light Blue Shirt")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_tshirt3_Click(object sender, EventArgs e)
        {
            ada16 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Patterned Shirt")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada16 = true;
                }
            }

            if (ada16 == false)
            {
                muncul.Rows.Add("Patterned Shirt", "1", "700000", "700000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada16 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Patterned Shirt")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_jewel1_Click(object sender, EventArgs e)
        {
            ada17 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Emerald")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada17 = true;
                }
            }

            if (ada17 == false)
            {
                muncul.Rows.Add("Emerald", "1", "5000000", "5000000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada17 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Emerald")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_jewel2_Click(object sender, EventArgs e)
        {
            ada18 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Diamond")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada18 = true;
                }
            }

            if (ada18 == false)
            {
                muncul.Rows.Add("Diamond", "1", "6000000", "6000000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada18 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Diamond")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_jewel3_Click(object sender, EventArgs e)
        {
            ada19 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Ruby")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada19 = true;
                }
            }

            if (ada19 == false)
            {
                muncul.Rows.Add("Ruby", "1", "7000000", "7000000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada19 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Ruby")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shorts1_Click(object sender, EventArgs e)
        {
            ada7 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Black Shorts")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada7 = true;
                }
            }

            if (ada7 == false)
            {
                muncul.Rows.Add("Black Shorts", "1", "100000", "100000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada7 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Black Shorts")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shorts2_Click(object sender, EventArgs e)
        {
            ada8 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Brown Shorts")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada8 = true;
                }
            }

            if (ada8 == false)
            {
                muncul.Rows.Add("Brown Shorts", "1", "200000", "200000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada8 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Brown Shorts")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shorts3_Click(object sender, EventArgs e)
        {
            ada9 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "White Shorts")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada9 = true;
                }
            }

            if (ada9 == false)
            {
                muncul.Rows.Add("White Shorts", "1", "300000", "300000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada9 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "White Shorts")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_longpants1_Click(object sender, EventArgs e)
        {
            ada4 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Black Long Pants")
                {
                    ada4 = true;
                }
            }

            if (ada4 == false)
            {
                muncul.Rows.Add("Black Long Pants", "1", "150000", "150000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada4 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Black Long Pants")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_longpants2_Click(object sender, EventArgs e)
        {
            ada5 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Brown Long Pants")
                {
                    ada5 = true;
                }
            }

            if (ada5 == false)
            {
                muncul.Rows.Add("Brown Long Pants", "1", "250000", "250000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada5 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Brown Long Pants")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_longpants3_Click(object sender, EventArgs e)
        {
            ada6 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Red Long Pants")
                {
                    ada6 = true;
                }
            }

            if (ada6 == false)
            {
                muncul.Rows.Add("Red Long Pants", "1", "350000", "350000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada6 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Red Long Pants")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void tb_itemprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void ganti_layar()
        {
            if (pnl_tshirt.Visible == true)
            {
                pnl_tshirt.Visible = false;
            }
            if (pnl_shirt.Visible == true)
            {
                pnl_shirt.Visible = false;
            }
            if (pnl_longpants.Visible == true)
            {
                pnl_longpants.Visible = false;
            }
            if (pnl_shorts.Visible == true)
            {
                pnl_shorts.Visible = false;
            }
            if (pnl_shoes.Visible == true)
            {
                pnl_shoes.Visible = false;
            }
            if (pnl_others.Visible == true)
            {
                pnl_others.Visible = false;
            }
            if (pnl_jewel.Visible == true)
            {
                pnl_jewel.Visible = false;
            }
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_jewel.Visible = true;
        }
        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_tshirt.Visible = true;
        }
        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_longpants.Visible = true;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_shoes.Visible = true;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_shirt.Visible = true;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_shorts.Visible = true;
        }



        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_others.Visible = true;
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            kurang = true;
            foreach (DataGridViewRow hapus in dgv_menu.SelectedRows)
            {

                dgv_menu.Rows.RemoveAt(hapus.Index);
                subtotal(harga, pajak, kurang);
            }
        }

        private void pnl_jewel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_shorts_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void btn_addother_Click(object sender, EventArgs e)
        {
            ada12 = false;

            if (tb_itemname.Text == "" && tb_itemprice.Text == "")
            {
                MessageBox.Show("masukan nama barang dan harga", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == tb_itemname.Text)
                    {
                        int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        ada12 = true;
                    }
                }

                if (ada12 == false)
                {
                    muncul.Rows.Add(tb_itemname.Text, "1", tb_itemprice.Text, tb_itemprice.Text);
                    subtotal(harga, pajak, kurang);
                }
                else if (ada12 == true)
                {
                    for (int i = 0; i < muncul.Rows.Count; i++)
                    {
                        if (muncul.Rows[i][0].ToString() == tb_itemname.Text)
                        {
                            int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                            int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                            int many = quan + 1;
                            muncul.Rows[i][1] = many.ToString();
                            muncul.Rows[i][3] = (biaya * many).ToString();
                            subtotal(harga, pajak, kurang);
                        }
                    }
                }
            }
        }
    }
}
