﻿namespace Takehome_Week08_Yoel_Isaac_0706022310020
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_menu = new System.Windows.Forms.DataGridView();
            this.lbl_subtotal = new System.Windows.Forms.Label();
            this.lbl_total = new System.Windows.Forms.Label();
            this.tb_subtotal = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.pnl_tshirt = new System.Windows.Forms.Panel();
            this.pnl_shoes = new System.Windows.Forms.Panel();
            this.btn_shoes2 = new System.Windows.Forms.Button();
            this.pnl_longpants = new System.Windows.Forms.Panel();
            this.btn_longpants2 = new System.Windows.Forms.Button();
            this.btn_longpants3 = new System.Windows.Forms.Button();
            this.btn_longpants1 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.btn_shoes3 = new System.Windows.Forms.Button();
            this.btn_shoes1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.btn_shirt2 = new System.Windows.Forms.Button();
            this.btn_shirt3 = new System.Windows.Forms.Button();
            this.btn_shirt1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnl_others = new System.Windows.Forms.Panel();
            this.tb_itemprice = new System.Windows.Forms.TextBox();
            this.pnl_shirt = new System.Windows.Forms.Panel();
            this.btn_tshirt2 = new System.Windows.Forms.Button();
            this.btn_tshirt3 = new System.Windows.Forms.Button();
            this.btn_tshirt1 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.tb_itemname = new System.Windows.Forms.TextBox();
            this.btn_upload = new System.Windows.Forms.Button();
            this.btn_addother = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.label37 = new System.Windows.Forms.Label();
            this.pnl_jewel = new System.Windows.Forms.Panel();
            this.btn_jewel2 = new System.Windows.Forms.Button();
            this.btn_jewel3 = new System.Windows.Forms.Button();
            this.btn_jewel1 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pnl_shorts = new System.Windows.Forms.Panel();
            this.btn_shorts2 = new System.Windows.Forms.Button();
            this.btn_shorts3 = new System.Windows.Forms.Button();
            this.btn_shorts1 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_menu)).BeginInit();
            this.pnl_tshirt.SuspendLayout();
            this.pnl_shoes.SuspendLayout();
            this.pnl_longpants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnl_others.SuspendLayout();
            this.pnl_shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            this.pnl_jewel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.pnl_shorts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(888, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dgv_menu
            // 
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_menu.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.dgv_menu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_menu.DefaultCellStyle = dataGridViewCellStyle29;
            this.dgv_menu.Location = new System.Drawing.Point(467, 4);
            this.dgv_menu.Name = "dgv_menu";
            this.dgv_menu.ReadOnly = true;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_menu.RowHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.dgv_menu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_menu.Size = new System.Drawing.Size(409, 249);
            this.dgv_menu.TabIndex = 1;
            // 
            // lbl_subtotal
            // 
            this.lbl_subtotal.AutoSize = true;
            this.lbl_subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_subtotal.Location = new System.Drawing.Point(435, 269);
            this.lbl_subtotal.Name = "lbl_subtotal";
            this.lbl_subtotal.Size = new System.Drawing.Size(121, 25);
            this.lbl_subtotal.TabIndex = 2;
            this.lbl_subtotal.Text = "Sub-Total:";
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_total.Location = new System.Drawing.Point(484, 313);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(72, 25);
            this.lbl_total.TabIndex = 3;
            this.lbl_total.Text = "Total:";
            // 
            // tb_subtotal
            // 
            this.tb_subtotal.Location = new System.Drawing.Point(562, 274);
            this.tb_subtotal.Name = "tb_subtotal";
            this.tb_subtotal.Size = new System.Drawing.Size(196, 20);
            this.tb_subtotal.TabIndex = 4;
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(562, 318);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(196, 20);
            this.tb_total.TabIndex = 5;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(779, 273);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 6;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // pnl_tshirt
            // 
            this.pnl_tshirt.Controls.Add(this.btn_shirt2);
            this.pnl_tshirt.Controls.Add(this.btn_shirt3);
            this.pnl_tshirt.Controls.Add(this.btn_shirt1);
            this.pnl_tshirt.Controls.Add(this.label6);
            this.pnl_tshirt.Controls.Add(this.label5);
            this.pnl_tshirt.Controls.Add(this.label4);
            this.pnl_tshirt.Controls.Add(this.label3);
            this.pnl_tshirt.Controls.Add(this.label2);
            this.pnl_tshirt.Controls.Add(this.label1);
            this.pnl_tshirt.Controls.Add(this.pictureBox3);
            this.pnl_tshirt.Controls.Add(this.pictureBox2);
            this.pnl_tshirt.Controls.Add(this.pictureBox1);
            this.pnl_tshirt.Location = new System.Drawing.Point(9, 35);
            this.pnl_tshirt.Name = "pnl_tshirt";
            this.pnl_tshirt.Size = new System.Drawing.Size(377, 261);
            this.pnl_tshirt.TabIndex = 7;
            this.pnl_tshirt.Visible = false;
            // 
            // pnl_shoes
            // 
            this.pnl_shoes.Controls.Add(this.btn_shoes2);
            this.pnl_shoes.Controls.Add(this.btn_shoes3);
            this.pnl_shoes.Controls.Add(this.btn_shoes1);
            this.pnl_shoes.Controls.Add(this.label7);
            this.pnl_shoes.Controls.Add(this.label8);
            this.pnl_shoes.Controls.Add(this.label9);
            this.pnl_shoes.Controls.Add(this.label10);
            this.pnl_shoes.Controls.Add(this.label11);
            this.pnl_shoes.Controls.Add(this.label12);
            this.pnl_shoes.Controls.Add(this.pictureBox4);
            this.pnl_shoes.Controls.Add(this.pictureBox5);
            this.pnl_shoes.Controls.Add(this.pictureBox6);
            this.pnl_shoes.Location = new System.Drawing.Point(405, 344);
            this.pnl_shoes.Name = "pnl_shoes";
            this.pnl_shoes.Size = new System.Drawing.Size(251, 182);
            this.pnl_shoes.TabIndex = 12;
            this.pnl_shoes.Visible = false;
            // 
            // btn_shoes2
            // 
            this.btn_shoes2.Location = new System.Drawing.Point(91, 157);
            this.btn_shoes2.Name = "btn_shoes2";
            this.btn_shoes2.Size = new System.Drawing.Size(75, 23);
            this.btn_shoes2.TabIndex = 11;
            this.btn_shoes2.Text = "Add to cart";
            this.btn_shoes2.UseVisualStyleBackColor = true;
            this.btn_shoes2.Click += new System.EventHandler(this.btn_shoes2_Click);
            // 
            // pnl_longpants
            // 
            this.pnl_longpants.Controls.Add(this.btn_longpants2);
            this.pnl_longpants.Controls.Add(this.btn_longpants3);
            this.pnl_longpants.Controls.Add(this.btn_longpants1);
            this.pnl_longpants.Controls.Add(this.label31);
            this.pnl_longpants.Controls.Add(this.label32);
            this.pnl_longpants.Controls.Add(this.label33);
            this.pnl_longpants.Controls.Add(this.label34);
            this.pnl_longpants.Controls.Add(this.label35);
            this.pnl_longpants.Controls.Add(this.label36);
            this.pnl_longpants.Controls.Add(this.pictureBox16);
            this.pnl_longpants.Controls.Add(this.pictureBox17);
            this.pnl_longpants.Controls.Add(this.pictureBox18);
            this.pnl_longpants.Location = new System.Drawing.Point(43, 318);
            this.pnl_longpants.Name = "pnl_longpants";
            this.pnl_longpants.Size = new System.Drawing.Size(279, 160);
            this.pnl_longpants.TabIndex = 16;
            this.pnl_longpants.Visible = false;
            // 
            // btn_longpants2
            // 
            this.btn_longpants2.Location = new System.Drawing.Point(96, 128);
            this.btn_longpants2.Name = "btn_longpants2";
            this.btn_longpants2.Size = new System.Drawing.Size(75, 23);
            this.btn_longpants2.TabIndex = 11;
            this.btn_longpants2.Text = "Add to cart";
            this.btn_longpants2.UseVisualStyleBackColor = true;
            this.btn_longpants2.Click += new System.EventHandler(this.btn_longpants2_Click);
            // 
            // btn_longpants3
            // 
            this.btn_longpants3.Location = new System.Drawing.Point(195, 128);
            this.btn_longpants3.Name = "btn_longpants3";
            this.btn_longpants3.Size = new System.Drawing.Size(75, 23);
            this.btn_longpants3.TabIndex = 10;
            this.btn_longpants3.Text = "Add to cart";
            this.btn_longpants3.UseVisualStyleBackColor = true;
            this.btn_longpants3.Click += new System.EventHandler(this.btn_longpants3_Click);
            // 
            // btn_longpants1
            // 
            this.btn_longpants1.Location = new System.Drawing.Point(0, 128);
            this.btn_longpants1.Name = "btn_longpants1";
            this.btn_longpants1.Size = new System.Drawing.Size(75, 23);
            this.btn_longpants1.TabIndex = 9;
            this.btn_longpants1.Text = "Add to cart";
            this.btn_longpants1.UseVisualStyleBackColor = true;
            this.btn_longpants1.Click += new System.EventHandler(this.btn_longpants1_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(196, 109);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(69, 13);
            this.label31.TabIndex = 8;
            this.label31.Text = "Rp. 350.000.";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(98, 109);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(66, 13);
            this.label32.TabIndex = 7;
            this.label32.Text = "Rp. 250.000";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(3, 109);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(66, 13);
            this.label33.TabIndex = 6;
            this.label33.Text = "Rp. 150.000";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(196, 89);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(84, 13);
            this.label34.TabIndex = 5;
            this.label34.Text = "Red Long Pants";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(96, 89);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(94, 13);
            this.label35.TabIndex = 4;
            this.label35.Text = "Brown Long Pants";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(-1, 87);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(91, 13);
            this.label36.TabIndex = 3;
            this.label36.Text = "Black Long Pants";
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.longpants3;
            this.pictureBox16.Location = new System.Drawing.Point(195, 0);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(66, 84);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 2;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.longpants2;
            this.pictureBox17.Location = new System.Drawing.Point(96, 0);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(63, 84);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 1;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.longpants1;
            this.pictureBox18.Location = new System.Drawing.Point(0, 0);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(69, 84);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 0;
            this.pictureBox18.TabStop = false;
            // 
            // btn_shoes3
            // 
            this.btn_shoes3.Location = new System.Drawing.Point(172, 157);
            this.btn_shoes3.Name = "btn_shoes3";
            this.btn_shoes3.Size = new System.Drawing.Size(75, 23);
            this.btn_shoes3.TabIndex = 10;
            this.btn_shoes3.Text = "Add to cart";
            this.btn_shoes3.UseVisualStyleBackColor = true;
            this.btn_shoes3.Click += new System.EventHandler(this.btn_shoes3_Click);
            // 
            // btn_shoes1
            // 
            this.btn_shoes1.Location = new System.Drawing.Point(6, 157);
            this.btn_shoes1.Name = "btn_shoes1";
            this.btn_shoes1.Size = new System.Drawing.Size(75, 23);
            this.btn_shoes1.TabIndex = 9;
            this.btn_shoes1.Text = "Add to cart";
            this.btn_shoes1.UseVisualStyleBackColor = true;
            this.btn_shoes1.Click += new System.EventHandler(this.btn_shoes1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(169, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Rp. 770.000";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(88, 141);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Rp. 660.000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 141);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "Rp. 550.000";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(169, 119);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "Purple Shoes";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(85, 119);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Red Shoes";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(2, 119);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "Black Shoes";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.shoes3;
            this.pictureBox4.Location = new System.Drawing.Point(172, 8);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(75, 99);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.shoes2;
            this.pictureBox5.Location = new System.Drawing.Point(88, 8);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(78, 101);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.shoes1;
            this.pictureBox6.Location = new System.Drawing.Point(2, 8);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(79, 101);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // btn_shirt2
            // 
            this.btn_shirt2.Location = new System.Drawing.Point(128, 227);
            this.btn_shirt2.Name = "btn_shirt2";
            this.btn_shirt2.Size = new System.Drawing.Size(75, 23);
            this.btn_shirt2.TabIndex = 11;
            this.btn_shirt2.Text = "Add to cart";
            this.btn_shirt2.UseVisualStyleBackColor = true;
            this.btn_shirt2.Click += new System.EventHandler(this.btn_shirt2_Click);
            // 
            // btn_shirt3
            // 
            this.btn_shirt3.Location = new System.Drawing.Point(256, 227);
            this.btn_shirt3.Name = "btn_shirt3";
            this.btn_shirt3.Size = new System.Drawing.Size(75, 23);
            this.btn_shirt3.TabIndex = 10;
            this.btn_shirt3.Text = "Add to cart";
            this.btn_shirt3.UseVisualStyleBackColor = true;
            this.btn_shirt3.Click += new System.EventHandler(this.btn_shirt3_Click);
            // 
            // btn_shirt1
            // 
            this.btn_shirt1.Location = new System.Drawing.Point(6, 227);
            this.btn_shirt1.Name = "btn_shirt1";
            this.btn_shirt1.Size = new System.Drawing.Size(75, 23);
            this.btn_shirt1.TabIndex = 9;
            this.btn_shirt1.Text = "Add to cart";
            this.btn_shirt1.UseVisualStyleBackColor = true;
            this.btn_shirt1.Click += new System.EventHandler(this.btn_shirt1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(253, 194);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Rp. 70.000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(125, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Rp. 60.000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 194);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Rp. 50.000";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(253, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "T-Shirt Blue";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(125, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "T-Shirt Beige";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 161);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "T-Shirt Grey";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.tshirt3;
            this.pictureBox3.Location = new System.Drawing.Point(241, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(96, 120);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.tshirt2;
            this.pictureBox2.Location = new System.Drawing.Point(128, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(107, 120);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.tshirt1;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(122, 120);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pnl_others
            // 
            this.pnl_others.Controls.Add(this.tb_itemprice);
            this.pnl_others.Controls.Add(this.tb_itemname);
            this.pnl_others.Controls.Add(this.btn_upload);
            this.pnl_others.Controls.Add(this.btn_addother);
            this.pnl_others.Controls.Add(this.label39);
            this.pnl_others.Controls.Add(this.label38);
            this.pnl_others.Controls.Add(this.pictureBox19);
            this.pnl_others.Controls.Add(this.label37);
            this.pnl_others.Location = new System.Drawing.Point(648, 352);
            this.pnl_others.Name = "pnl_others";
            this.pnl_others.Size = new System.Drawing.Size(228, 168);
            this.pnl_others.TabIndex = 17;
            this.pnl_others.Visible = false;
            // 
            // tb_itemprice
            // 
            this.tb_itemprice.Location = new System.Drawing.Point(115, 113);
            this.tb_itemprice.Name = "tb_itemprice";
            this.tb_itemprice.Size = new System.Drawing.Size(100, 20);
            this.tb_itemprice.TabIndex = 18;
            this.tb_itemprice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_itemprice_KeyPress);
            // 
            // pnl_shirt
            // 
            this.pnl_shirt.Controls.Add(this.btn_tshirt2);
            this.pnl_shirt.Controls.Add(this.btn_tshirt3);
            this.pnl_shirt.Controls.Add(this.btn_tshirt1);
            this.pnl_shirt.Controls.Add(this.label13);
            this.pnl_shirt.Controls.Add(this.label14);
            this.pnl_shirt.Controls.Add(this.label15);
            this.pnl_shirt.Controls.Add(this.label16);
            this.pnl_shirt.Controls.Add(this.label17);
            this.pnl_shirt.Controls.Add(this.label18);
            this.pnl_shirt.Controls.Add(this.pictureBox7);
            this.pnl_shirt.Controls.Add(this.pictureBox8);
            this.pnl_shirt.Controls.Add(this.pictureBox9);
            this.pnl_shirt.Location = new System.Drawing.Point(118, 302);
            this.pnl_shirt.Name = "pnl_shirt";
            this.pnl_shirt.Size = new System.Drawing.Size(257, 158);
            this.pnl_shirt.TabIndex = 13;
            this.pnl_shirt.Visible = false;
            // 
            // btn_tshirt2
            // 
            this.btn_tshirt2.Location = new System.Drawing.Point(86, 126);
            this.btn_tshirt2.Name = "btn_tshirt2";
            this.btn_tshirt2.Size = new System.Drawing.Size(75, 23);
            this.btn_tshirt2.TabIndex = 11;
            this.btn_tshirt2.Text = "Add to cart";
            this.btn_tshirt2.UseVisualStyleBackColor = true;
            this.btn_tshirt2.Click += new System.EventHandler(this.btn_tshirt2_Click);
            // 
            // btn_tshirt3
            // 
            this.btn_tshirt3.Location = new System.Drawing.Point(173, 126);
            this.btn_tshirt3.Name = "btn_tshirt3";
            this.btn_tshirt3.Size = new System.Drawing.Size(75, 23);
            this.btn_tshirt3.TabIndex = 10;
            this.btn_tshirt3.Text = "Add to cart";
            this.btn_tshirt3.UseVisualStyleBackColor = true;
            this.btn_tshirt3.Click += new System.EventHandler(this.btn_tshirt3_Click);
            // 
            // btn_tshirt1
            // 
            this.btn_tshirt1.Location = new System.Drawing.Point(0, 126);
            this.btn_tshirt1.Name = "btn_tshirt1";
            this.btn_tshirt1.Size = new System.Drawing.Size(75, 23);
            this.btn_tshirt1.TabIndex = 9;
            this.btn_tshirt1.Text = "Add to cart";
            this.btn_tshirt1.UseVisualStyleBackColor = true;
            this.btn_tshirt1.Click += new System.EventHandler(this.btn_tshirt1_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(170, 107);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = "Rp. 700.000";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(83, 107);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 13);
            this.label14.TabIndex = 7;
            this.label14.Text = "Rp. 600.000";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 107);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(66, 13);
            this.label15.TabIndex = 6;
            this.label15.Text = "Rp. 500.000";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(169, 85);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 13);
            this.label16.TabIndex = 5;
            this.label16.Text = "Patterned Shirt";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(83, 85);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(78, 13);
            this.label17.TabIndex = 4;
            this.label17.Text = "Light Blue Shirt";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 85);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 13);
            this.label18.TabIndex = 3;
            this.label18.Text = "Navy Shirt";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.shirt3;
            this.pictureBox7.Location = new System.Drawing.Point(172, 0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(64, 82);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 2;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.shirt2;
            this.pictureBox8.Location = new System.Drawing.Point(86, 0);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(70, 82);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 1;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.shirt1;
            this.pictureBox9.Location = new System.Drawing.Point(0, 0);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(69, 82);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // tb_itemname
            // 
            this.tb_itemname.Location = new System.Drawing.Point(121, 64);
            this.tb_itemname.Name = "tb_itemname";
            this.tb_itemname.Size = new System.Drawing.Size(100, 20);
            this.tb_itemname.TabIndex = 17;
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(115, 10);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(75, 23);
            this.btn_upload.TabIndex = 16;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            // 
            // btn_addother
            // 
            this.btn_addother.Location = new System.Drawing.Point(115, 139);
            this.btn_addother.Name = "btn_addother";
            this.btn_addother.Size = new System.Drawing.Size(75, 23);
            this.btn_addother.TabIndex = 12;
            this.btn_addother.Text = "Add to cart";
            this.btn_addother.UseVisualStyleBackColor = true;
            this.btn_addother.Click += new System.EventHandler(this.btn_addother_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(118, 97);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(60, 13);
            this.label39.TabIndex = 15;
            this.label39.Text = "Item Price: ";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(115, 48);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(61, 13);
            this.label38.TabIndex = 14;
            this.label38.Text = "Item Name:";
            // 
            // pictureBox19
            // 
            this.pictureBox19.Location = new System.Drawing.Point(25, 48);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(70, 97);
            this.pictureBox19.TabIndex = 13;
            this.pictureBox19.TabStop = false;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(23, 20);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(73, 13);
            this.label37.TabIndex = 12;
            this.label37.Text = "Upload Image";
            // 
            // pnl_jewel
            // 
            this.pnl_jewel.Controls.Add(this.btn_jewel2);
            this.pnl_jewel.Controls.Add(this.btn_jewel3);
            this.pnl_jewel.Controls.Add(this.btn_jewel1);
            this.pnl_jewel.Controls.Add(this.label19);
            this.pnl_jewel.Controls.Add(this.label20);
            this.pnl_jewel.Controls.Add(this.label21);
            this.pnl_jewel.Controls.Add(this.label22);
            this.pnl_jewel.Controls.Add(this.label23);
            this.pnl_jewel.Controls.Add(this.label24);
            this.pnl_jewel.Controls.Add(this.pictureBox10);
            this.pnl_jewel.Controls.Add(this.pictureBox11);
            this.pnl_jewel.Controls.Add(this.pictureBox12);
            this.pnl_jewel.Location = new System.Drawing.Point(12, 38);
            this.pnl_jewel.Name = "pnl_jewel";
            this.pnl_jewel.Size = new System.Drawing.Size(377, 261);
            this.pnl_jewel.TabIndex = 14;
            this.pnl_jewel.Visible = false;
            this.pnl_jewel.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_jewel_Paint);
            // 
            // btn_jewel2
            // 
            this.btn_jewel2.Location = new System.Drawing.Point(128, 227);
            this.btn_jewel2.Name = "btn_jewel2";
            this.btn_jewel2.Size = new System.Drawing.Size(75, 23);
            this.btn_jewel2.TabIndex = 11;
            this.btn_jewel2.Text = "Add to cart";
            this.btn_jewel2.UseVisualStyleBackColor = true;
            this.btn_jewel2.Click += new System.EventHandler(this.btn_jewel2_Click);
            // 
            // btn_jewel3
            // 
            this.btn_jewel3.Location = new System.Drawing.Point(256, 227);
            this.btn_jewel3.Name = "btn_jewel3";
            this.btn_jewel3.Size = new System.Drawing.Size(75, 23);
            this.btn_jewel3.TabIndex = 10;
            this.btn_jewel3.Text = "Add to cart";
            this.btn_jewel3.UseVisualStyleBackColor = true;
            this.btn_jewel3.Click += new System.EventHandler(this.btn_jewel3_Click);
            // 
            // btn_jewel1
            // 
            this.btn_jewel1.Location = new System.Drawing.Point(6, 227);
            this.btn_jewel1.Name = "btn_jewel1";
            this.btn_jewel1.Size = new System.Drawing.Size(75, 23);
            this.btn_jewel1.TabIndex = 9;
            this.btn_jewel1.Text = "Add to cart";
            this.btn_jewel1.UseVisualStyleBackColor = true;
            this.btn_jewel1.Click += new System.EventHandler(this.btn_jewel1_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(253, 194);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(78, 13);
            this.label19.TabIndex = 8;
            this.label19.Text = "Rp. 7.000.000.";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(125, 194);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 13);
            this.label20.TabIndex = 7;
            this.label20.Text = "Rp. 6.000.000";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(3, 194);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(75, 13);
            this.label21.TabIndex = 6;
            this.label21.Text = "Rp. 5.000.000";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(253, 161);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(32, 13);
            this.label22.TabIndex = 5;
            this.label22.Text = "Ruby";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(125, 161);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(49, 13);
            this.label23.TabIndex = 4;
            this.label23.Text = "Diamond";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(3, 161);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(45, 13);
            this.label24.TabIndex = 3;
            this.label24.Text = "Emerald";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.jewellery3;
            this.pictureBox10.Location = new System.Drawing.Point(256, 0);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(122, 146);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 2;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.jewellery2;
            this.pictureBox11.Location = new System.Drawing.Point(128, 0);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(122, 146);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 1;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.jewellery1;
            this.pictureBox12.Location = new System.Drawing.Point(0, 0);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(122, 146);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 0;
            this.pictureBox12.TabStop = false;
            // 
            // pnl_shorts
            // 
            this.pnl_shorts.Controls.Add(this.btn_shorts2);
            this.pnl_shorts.Controls.Add(this.btn_shorts3);
            this.pnl_shorts.Controls.Add(this.btn_shorts1);
            this.pnl_shorts.Controls.Add(this.label25);
            this.pnl_shorts.Controls.Add(this.label26);
            this.pnl_shorts.Controls.Add(this.label27);
            this.pnl_shorts.Controls.Add(this.label28);
            this.pnl_shorts.Controls.Add(this.label29);
            this.pnl_shorts.Controls.Add(this.label30);
            this.pnl_shorts.Controls.Add(this.pictureBox13);
            this.pnl_shorts.Controls.Add(this.pictureBox14);
            this.pnl_shorts.Controls.Add(this.pictureBox15);
            this.pnl_shorts.Location = new System.Drawing.Point(160, 344);
            this.pnl_shorts.Name = "pnl_shorts";
            this.pnl_shorts.Size = new System.Drawing.Size(230, 181);
            this.pnl_shorts.TabIndex = 15;
            this.pnl_shorts.Visible = false;
            this.pnl_shorts.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_shorts_Paint);
            // 
            // btn_shorts2
            // 
            this.btn_shorts2.Location = new System.Drawing.Point(78, 149);
            this.btn_shorts2.Name = "btn_shorts2";
            this.btn_shorts2.Size = new System.Drawing.Size(75, 23);
            this.btn_shorts2.TabIndex = 11;
            this.btn_shorts2.Text = "Add to cart";
            this.btn_shorts2.UseVisualStyleBackColor = true;
            this.btn_shorts2.Click += new System.EventHandler(this.btn_shorts2_Click);
            // 
            // btn_shorts3
            // 
            this.btn_shorts3.Location = new System.Drawing.Point(156, 149);
            this.btn_shorts3.Name = "btn_shorts3";
            this.btn_shorts3.Size = new System.Drawing.Size(75, 23);
            this.btn_shorts3.TabIndex = 10;
            this.btn_shorts3.Text = "Add to cart";
            this.btn_shorts3.UseVisualStyleBackColor = true;
            this.btn_shorts3.Click += new System.EventHandler(this.btn_shorts3_Click);
            // 
            // btn_shorts1
            // 
            this.btn_shorts1.Location = new System.Drawing.Point(0, 149);
            this.btn_shorts1.Name = "btn_shorts1";
            this.btn_shorts1.Size = new System.Drawing.Size(75, 23);
            this.btn_shorts1.TabIndex = 9;
            this.btn_shorts1.Text = "Add to cart";
            this.btn_shorts1.UseVisualStyleBackColor = true;
            this.btn_shorts1.Click += new System.EventHandler(this.btn_shorts1_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(153, 130);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(69, 13);
            this.label25.TabIndex = 8;
            this.label25.Text = "Rp. 300.000.";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(79, 130);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(66, 13);
            this.label26.TabIndex = 7;
            this.label26.Text = "Rp. 200.000";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(2, 130);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(66, 13);
            this.label27.TabIndex = 6;
            this.label27.Text = "Rp. 100.000";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(153, 105);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(68, 13);
            this.label28.TabIndex = 5;
            this.label28.Text = "White Shorts";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(75, 105);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(70, 13);
            this.label29.TabIndex = 4;
            this.label29.Text = "Brown Shorts";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(2, 105);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(67, 13);
            this.label30.TabIndex = 3;
            this.label30.Text = "Black Shorts";
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.pants3;
            this.pictureBox13.Location = new System.Drawing.Point(156, 3);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(75, 93);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 2;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.pants2;
            this.pictureBox14.Location = new System.Drawing.Point(75, 0);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(75, 96);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 1;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::Takehome_Week08_Yoel_Isaac_0706022310020.Properties.Resources.pants1;
            this.pictureBox15.Location = new System.Drawing.Point(0, 0);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(69, 96);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 0;
            this.pictureBox15.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 550);
            this.Controls.Add(this.pnl_shirt);
            this.Controls.Add(this.pnl_longpants);
            this.Controls.Add(this.pnl_shoes);
            this.Controls.Add(this.pnl_others);
            this.Controls.Add(this.pnl_shorts);
            this.Controls.Add(this.pnl_tshirt);
            this.Controls.Add(this.pnl_jewel);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_subtotal);
            this.Controls.Add(this.lbl_total);
            this.Controls.Add(this.lbl_subtotal);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.dgv_menu);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_menu)).EndInit();
            this.pnl_tshirt.ResumeLayout(false);
            this.pnl_tshirt.PerformLayout();
            this.pnl_shoes.ResumeLayout(false);
            this.pnl_shoes.PerformLayout();
            this.pnl_longpants.ResumeLayout(false);
            this.pnl_longpants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnl_others.ResumeLayout(false);
            this.pnl_others.PerformLayout();
            this.pnl_shirt.ResumeLayout(false);
            this.pnl_shirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            this.pnl_jewel.ResumeLayout(false);
            this.pnl_jewel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.pnl_shorts.ResumeLayout(false);
            this.pnl_shorts.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_menu;
        private System.Windows.Forms.Label lbl_subtotal;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.TextBox tb_subtotal;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Panel pnl_tshirt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_shirt2;
        private System.Windows.Forms.Button btn_shirt3;
        private System.Windows.Forms.Button btn_shirt1;
        private System.Windows.Forms.Panel pnl_shoes;
        private System.Windows.Forms.Button btn_shoes2;
        private System.Windows.Forms.Button btn_shoes3;
        private System.Windows.Forms.Button btn_shoes1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel pnl_shirt;
        private System.Windows.Forms.Button btn_tshirt2;
        private System.Windows.Forms.Button btn_tshirt3;
        private System.Windows.Forms.Button btn_tshirt1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Panel pnl_jewel;
        private System.Windows.Forms.Button btn_jewel2;
        private System.Windows.Forms.Button btn_jewel3;
        private System.Windows.Forms.Button btn_jewel1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Panel pnl_shorts;
        private System.Windows.Forms.Button btn_shorts2;
        private System.Windows.Forms.Button btn_shorts3;
        private System.Windows.Forms.Button btn_shorts1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Panel pnl_longpants;
        private System.Windows.Forms.Button btn_longpants2;
        private System.Windows.Forms.Button btn_longpants3;
        private System.Windows.Forms.Button btn_longpants1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.Panel pnl_others;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.Button btn_addother;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox tb_itemprice;
        private System.Windows.Forms.TextBox tb_itemname;
    }
}

